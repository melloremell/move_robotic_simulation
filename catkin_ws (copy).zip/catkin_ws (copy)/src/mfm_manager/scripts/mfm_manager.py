#!/usr/bin/env python
# license removed for brevity

import rospy
import actionlib
import json

from tf2_msgs.msg import TFMessage
from std_msgs.msg import Float32
from nav_msgs.msg import Odometry
from geometry_msgs.msg import PoseWithCovarianceStamped
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
import sys
from std_msgs.msg import String, Float64MultiArray

class mfm_manager():
    
    def __init__(self):
        self.endtime = rospy.Time.now()
        self.pubAct = rospy.Publisher('/action/conveyor', String, queue_size=10)
        self.pubMFM = rospy.Publisher('/mk_health', String, queue_size=10)

        self.stateSub = rospy.Subscriber("/amr/state", String, self.statecallback)
        self.naviSub = rospy.Subscriber("/mk_navigoal", String, self.navicallback)
        self.actionSub = rospy.Subscriber("/action/conveyor/stat", String, self.actioncallback)
        self.currentSub = rospy.Subscriber("/amr/current", String, self.curcallback)
        self.voltageSub = rospy.Subscriber("/amr/battery", String, self.battcallback)
        self.odomSub = rospy.Subscriber("/odometry/filtered", Odometry, self.odomcallback)#speed and xy
        self.ptSub = rospy.Subscriber("/amcl_pose", PoseWithCovarianceStamped, self.ptcallback)#pt
        self.StatePub = rospy.Publisher('/amr/statechange', String, queue_size=10)

        self.Robot="MK_01"
        self.Map = "NO_MAP"
        self.Lat = "0.0"
        self.x = "0.0"
        self.Long = "0.0"
        self.y = "0.0"
        self.JID = "0"
        self.Mode = "IDLE"
        self.Batt = "0"
        self.Err = "0"
        self.Xspd = "0.0"
        self.Zspd = "0.0"
        self.Cur = "0"
        self.Act="0"

        self.cnt = 0

    def movebase_client(self,x,y,z,qx,qy,qz,qw):

        client = actionlib.SimpleActionClient('move_base',MoveBaseAction)
        client.wait_for_server()

        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now()
        goal.target_pose.pose.position.x = float(x)
        goal.target_pose.pose.position.y = float(y)
        goal.target_pose.pose.position.z = float(z)
        goal.target_pose.pose.orientation.x = float(qx)
        goal.target_pose.pose.orientation.y = float(qy)
        goal.target_pose.pose.orientation.z = float(qz)
        goal.target_pose.pose.orientation.w = float(qw)

        client.send_goal(goal)
        print(goal)
        wait = client.wait_for_result()
        if not wait:
            rospy.logerr("Action server not available!")
            rospy.signal_shutdown("Action server not available!")
        else:
            return client.get_result()


    def navicallback(self,msg):#data received: x,y,z,qx,qy,qz,qw,actID,jobID,map
        r=msg.data.split(",")
        self.Mode="MOVE"
        self.JID=r[8]
        self.Act=r[7].strip()
        print(r)
        self.Map=r[9]
        rospy.loginfo("Receiving Goal to x:"+r[0]+", y:"+r[1])
        result = self.movebase_client(r[0],r[1],r[2],r[3],r[4],r[5],r[6])
        if result:
            rospy.loginfo("Goal execution done!")
            if self.Act == "WAIT":
                self.StatePub.publish("DONE")
                print("Stopped..")
            else:
                self.StatePub.publish("ACTION")
                self.pubAct.publish(self.Act)
                print("Waiting action to complete..")

    def statecallback(self,msg):
        self.Mode=str(msg.data)

    def battcallback(self,msg):
        self.Batt=str(msg.data)

    def curcallback(self,msg):
        self.Cur=str(msg.data)

    def ptcallback(self,msg):
        self.x=str(msg.pose.pose.position.x)
        self.y=str(msg.pose.pose.position.y)

    def actioncallback(self,msg):
        recv_data=msg.data
        if recv_data=="DONE":
            self.StatePub.publish("DONE")


    def odomcallback(self,msg):
        starttime = rospy.Time.now()
        dura =  starttime - self.endtime
        if dura.to_sec() > 1:
            self.Xspd=str(msg.twist.twist.linear.x)
            self.Zspd=str(msg.twist.twist.angular.z)
            if self.Mode=="DONE":#publish Done 2x then change to IDLE
                self.cnt = self.cnt + 1
            if self.cnt == 2:
                print ("All Mission Done")
                self.StatePub.publish("IDLE")
                self.cnt=0
            self.pubMFM.publish(self.Robot+","+self.Map+","+self.Lat+
                ","+self.x+","+self.Long+","+self.y+","+self.JID+","+
                self.Mode+","+self.Batt+","+self.Err+","+self.Xspd+
                ","+self.Zspd+","+self.Cur)
            self.endtime = rospy.Time.now()

if __name__ == '__main__':
    try:
        rospy.init_node('mfm_manager_py')
        mfm_manager()

        rospy.spin()
    except rospy.ROSInterruptException:
        rospy.loginfo("Navigation test finished.")