#!/usr/bin/env python

import rospy
import numpy as np

from pygame import mixer
from mk_support.srv import mk_audio


class Audio():
    def __init__(self):
        self.def_audio = "/home/mover01/def2.ogg"
        # Service Server
        self.audioserv = rospy.Service("/amr/audio", mk_audio, self.audSRV)

        # Initialize Sound Control
        mixer.init()
        mixer.music.load(self.def_audio)
        mixer.music.play(-1)

    def audSRV(self, req):
        if req.path=="/OFF/":
            mixer.music.pause()
        else:
            mixer.music.load(req.path)
            mixer.music.play(-1)
        return ()



if __name__=="__main__":
    rospy.init_node("audio")
    Audio()
    print("AUDIO MANAGER ON")
    rospy.spin()
