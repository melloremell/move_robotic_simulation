#!/usr/bin/env python
# license removed for brevity

import rospy
import sys

from std_msgs.msg import String, Float64MultiArray

class battery():
    
    def __init__(self):
        self.pubCur = rospy.Publisher('/amr/current', String, queue_size=10)
        self.pubBatt = rospy.Publisher('/amr/battery', String, queue_size=10)

        self.voltageSub = rospy.Subscriber("/mrc10100/voltage_current", Float64MultiArray, self.volcurcallback)#battery voltage n current

    def volcurcallback(self,msg):
        b=msg.data[0]
        bb=str((b-20.5)/5.07875*100)
        cur=str(msg.data[1])
        self.pubBatt.publish(bb)
        self.pubCur.publish(cur)


if __name__ == '__main__':
    try:
        rospy.init_node('battery')
        battery()

        print("BATTERY MANAGER ON")

        rospy.spin()
    except rospy.ROSInterruptException:
        rospy.loginfo("battery ended")