#!/usr/bin/env python

import rospy
import sys
import numpy as np

from std_msgs.msg import String, Int16MultiArray

class susres():
    
    def __init__(self):
        self.endtime = rospy.Time.now()
        self.StatePub = rospy.Publisher('/amr/statechange', String, queue_size=10)
        self.LEDPub = rospy.Publisher('/amr/led', String, queue_size=10)
        self.gpiSub = rospy.Subscriber("/mrc10100/gpi", Int16MultiArray, self.gpicallback)
        self.srSub = rospy.Subscriber("mk_susres", String, self.susrescallback)
        self.stateSub = rospy.Subscriber("/amr/state", String, self.statecallback)

        self.state=""
        self.sSW = 0
        self.rSW = 0

    def gpicallback(self,msg):
        s=msg.data[1]
        if(s==0 and  self.sSW==1):
            self.sroutine("SUSPEND")
            # print("S")
        r=msg.data[0]
        if(r==0 and  self.rSW==1):
            self.sroutine("RESUME")
            # print("R")
        self.sSW=s
        self.rSW=r


    def susrescallback(self,msg):
        sr=str(msg.data)
        self.sroutine(sr)

    def statecallback(self,msg):
        self.state=str(msg.data)


    def sroutine(self,msg):
        if(msg=="SUSPEND"):
            self.StatePub.publish("SUSPEND")
        elif(msg=="RESUME" and self.state=="SUSPEND"):
            self.StatePub.publish("PREVIOUS")

if __name__ == '__main__':
    try:
        rospy.init_node('susres')
        susres()
        print("SUSPEND RESUME ON")
        rospy.spin()
    except rospy.ROSInterruptException:
        rospy.loginfo("susres ended")