#!/usr/bin/env python

import rospy
import sys
import numpy as np

from std_msgs.msg import String, Int16MultiArray

class amrstate():
    
    def __init__(self):
        self.endtime = rospy.Time.now()
        self.StatePub = rospy.Publisher('/amr/state', String, queue_size=10)
        self.StateSub = rospy.Subscriber("/amr/statechange", String, self.statecallback)
        self.LEDPub = rospy.Publisher('/amr/led', String, queue_size=10)
        self.prevState="IDLE"
        self.curState="IDLE"

        self.rate = rospy.Rate(10) # 10hz
        while not rospy.is_shutdown():
            self.pubstate()
            self.rate.sleep()


    def pubstate(self):
        self.StatePub.publish(self.curState)


    def statecallback(self,msg):
        r=msg.data
        if (r=="PREVIOUS"):
            self.curState=self.prevState
        else:
            self.curState=r

        if(self.curState=="IDLE"):
            self.LEDPub.publish("7,0")
        elif(self.curState=="SUSPEND"):
            self.LEDPub.publish("5,0.3")
        elif(self.curState=="MOVE"):
            self.LEDPub.publish("6,1")
        elif(self.curState=="ACTION"):
            self.LEDPub.publish("3,1")
        elif(self.curState=="CHARGE"):
            self.LEDPub.publish("2,1")
        elif(self.curState=="ERROR"):
            self.LEDPub.publish("4,0.5")
        elif(self.curState=="DONE"):
            self.LEDPub.publish("7,0") 


if __name__ == '__main__':
    try:
        rospy.init_node('amrstate')
        amrstate()
        print("STATE MACHINE ON")
        

    except rospy.ROSInterruptException:
        rospy.loginfo("amrstate ended")