#!/usr/bin/env python
# license removed for brevity

import rospy
import sys
import psutil

from std_msgs.msg import String, Float64MultiArray,Int16MultiArray
from bond.msg import Status
from sensor_msgs import LaserScan


class dignostic():
    
    def __init__(self):
        self.pubCur = rospy.Publisher('/amr/current', String, queue_size=10)

        self.volcurSub = rospy.Subscriber("/mrc10100/voltage_current", Float64MultiArray, self.volcurcallback)
        self.battSub = rospy.Subscriber("/mrc10100/voltage_current", String, self.battcallback)
        self.lidfSub = rospy.Subscriber("/laser_front/scan", LaserScan, self.lfcallback)
        self.lidrSub = rospy.Subscriber("/laser_rear/scan", LaserScan, self.lrcallback)
        self.camSub = rospy.Subscriber("/camera/realsense2_camera_manager/bond", Status, self.camcallback)
        self.conSub = rospy.Subscriber("/mrc10100/status", Int16MultiArray, self.ctcallback)


        self.battery = "0"
        self.current = "0"
        self.voltage = "0"
        self.lidarfront = "0"
        self.lidarback = "0"
        self.camera = "0"
        self.cpu = "0"
        self.controller = "0"


    def volcurcallback(self,msg):
        self.battery=msg.data[0]
        self.battery=msg.data[1]
        str(psutil.cpu_percent())

    def battcallback(self,msg):
        self.battery=msg.data

    def lfcallback(self,msg):
        if (msg.data.scan_time)


    def lrcallback(self,msg):
        self.battery=msg.data[0]
        self.battery=msg.data[1]


    def camcallback(self,msg):
        if(msg.data.active==True):
        self.camera="1"
        else:
            self.camera="0"

    def ctcallback(self,msg):
        if(msg.data[2]==0):
            self.controller="1"
        else:
            self.controller="0"




if __name__ == '__main__':
    try:
        rospy.init_node('dignostic')
        dignostic()

        print("DIAGNOSTIC MANAGER ON")

        rospy.spin()
    except rospy.ROSInterruptException:
        rospy.loginfo("dignostic ended")