#!/usr/bin/env python
# license removed for brevity

import rospy
import sys
import numpy as np

from std_msgs.msg import String, Int16MultiArray
from std_msgs.msg import MultiArrayDimension

class led():
    
    def __init__(self):
        self.endtime = rospy.Time.now()
        self.pubGpo = rospy.Publisher('/mrc10100/gpo_write', Int16MultiArray, queue_size=10)

        self.gpostateSub = rospy.Subscriber("/mrc10100/gpo_read", Int16MultiArray, self.gpocallback)
        self.ledSub = rospy.Subscriber("/amr/led", String, self.ledcallback)
        self.pin4 = "0"
        self.rgb=7
        self.blink=0
        self.toggle = True

        self.rate = rospy.Rate(10) # 10hz
        while not rospy.is_shutdown():
            self.ledons()
            self.rate.sleep()


    def gpocallback(self,msg):
        self.pin4=str(msg.data[4])


    def ledons(self):
        if self.blink==0:
            light = str(bin(self.rgb)[2:].zfill(3))
            gpostr=light+"0"+self.pin4+"0" 
            data = [int(i) for i in gpostr]
            gpo = Int16MultiArray()
            gpo.layout.dim.append(MultiArrayDimension())
            gpo.layout.dim[0].size = 6
            gpo.layout.dim[0].stride = 1
            gpo.layout.dim[0].label = "write_gpo";
            gpo.data = np.array(data)*127
            self.pubGpo.publish(gpo)
            # print("NO BLINK")
        else:
            # print("BLINK")
            starttime = rospy.Time.now()
            dura =  starttime - self.endtime
            if dura.to_sec() > self.blink:
                #toggle
                if(self.toggle):
                    light = str(bin(self.rgb)[2:].zfill(3))
                    gpostr=light+"0"+self.pin4+"0" 
                    data = [int(i) for i in gpostr]
                    gpo = Int16MultiArray()
                    gpo.layout.dim.append(MultiArrayDimension())
                    gpo.layout.dim[0].size = 6
                    gpo.layout.dim[0].stride = 1
                    gpo.layout.dim[0].label = "write_gpo";
                    gpo.data = np.array(data)*127
                    self.pubGpo.publish(gpo)
                    # print("ON")
                    self.toggle =  not self.toggle
                else:
                    data =[0,0,0,0,int(self.pin4),0]
                    gpo = Int16MultiArray()
                    gpo.layout.dim.append(MultiArrayDimension())
                    gpo.layout.dim[0].size = 6
                    gpo.layout.dim[0].stride = 1
                    gpo.layout.dim[0].label = "write_gpo";
                    gpo.data = np.array(data)*127
                    self.pubGpo.publish(gpo)
                    # print("OFF")
                    self.toggle = not self.toggle
                self.endtime = rospy.Time.now()

    def ledcallback(self,msg):
        r=msg.data.split(",")
        self.rgb=int(r[0])
        self.blink=float(r[1])
        



if __name__ == '__main__':
    try:
        rospy.init_node('led')
        led()
        print("LED CONTROL ON")

    except rospy.ROSInterruptException:
        rospy.loginfo("led ended")