
"use strict";

let mk_audio = require('./mk_audio.js')

module.exports = {
  mk_audio: mk_audio,
};
